package raspored;

public class GDodaj extends Exception {
public String toString() {
	return "Nije moguce dodavanje";
}
}
