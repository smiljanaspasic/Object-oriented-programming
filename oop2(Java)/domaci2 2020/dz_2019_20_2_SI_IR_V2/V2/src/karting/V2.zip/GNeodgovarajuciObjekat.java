package karting;

public class GNeodgovarajuciObjekat extends Exception {
public String toString() {
	return "Zadati objekat nije odgovarajuc";
}
}
