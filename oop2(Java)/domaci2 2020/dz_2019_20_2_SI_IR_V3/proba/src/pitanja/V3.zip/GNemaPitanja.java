package pitanja;

public class GNemaPitanja extends Exception {
public String toString() {
	return "Nema tekuceg elementa";
}
}
