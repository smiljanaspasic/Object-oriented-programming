
public class Krtica {

}
