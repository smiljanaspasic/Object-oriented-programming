
public class Basta {

}
